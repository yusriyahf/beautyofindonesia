<!-- Topbar Start -->
<!-- <div class="container-fluid d-none d-lg-block">
    <div class="row align-items-center bg-white py-3 px-lg-5">
        <div class="col-lg-4">
            <a href="/" class="navbar-brand p-0 d-none d-lg-block">
                
                <img src="https://beautyofindonesia.com/assets/images/logoHeader.png" alt="SumbarSpot Logo" style="height: 60px;" class="d-inline-block align-middle mr-2">
                
                <h1 class="m-0 d-inline-block align-middle display-4 text-uppercase text-primary">
                    <span class="text-secondary font-weight-normal">SumbarSpot</span>
                </h1>
            </a>
        </div>
    </div>
</div> -->
<!-- Topbar End -->
