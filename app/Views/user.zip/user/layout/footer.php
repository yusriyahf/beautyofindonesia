<div class="container-fluid py-4 px-sm-3 px-md-5" style="background: #111111;">
    <p class="m-0 text-center">
        <?php if (isset($tentang[0]['footer'])): ?>
            <a style="color: #fff;" href="https://htmlcodex.com"><?= $tentang[0]['footer'] ?></a>
        <?php else: ?>
            <a style="color: #fff;" href="#"></a>
        <?php endif; ?>
    </p>
</div>
