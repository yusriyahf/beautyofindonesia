<?= $this->extend('admin/template/template'); ?>
<?= $this->Section('content'); ?>

<div class="app-content pt-3 p-md-3 p-lg-4">
    <div class="container-xl">
        <h1 class="app-page-title">Edit Tempat Wisata</h1>
        <hr class="mb-4">
        <div class="row g-4 settings-section">
            <div class="col-12 col-md-8">
                <div class="app-card app-card-settings shadow-sm p-4">
                    <div class="card-body">
                        <form action="<?= base_url('admin/tempat_wisata/proses_edit/' . $wisata['id_wisata']) ?>" method="POST" class="needs-validation" novalidate>
                            <?= csrf_field() ?>

                            <div class="row">
                                <div class="col">
                                    <!-- Nama Wisata -->
                                    <div class="mb-3">
                                        <label for="nama_wisata" class="form-label">Nama Wisata</label>
                                        <input type="text" class="form-control" id="nama_wisata" name="nama_wisata" value="<?= $wisata['nama_wisata'] ?>" required>
                                        <div class="invalid-feedback">
                                            Nama wisata wajib diisi.
                                        </div>
                                    </div>

                                    <!-- Kategori Wisata -->
                                    <div class="mb-3">
                                        <label for="id_kategori_wisata" class="form-label">Kategori Wisata</label>
                                        <select class="form-select" id="id_kategori_wisata" name="id_kategori_wisata" required>
                                            <option value="" disabled>Pilih kategori wisata</option>
                                            <?php foreach ($kategori_wisata as $kategori) : ?>
                                                <option value="<?= $kategori['id_kategori_wisata'] ?>" <?= $kategori['id_kategori_wisata'] == $wisata['id_kategori_wisata'] ? 'selected' : '' ?>>
                                                    <?= $kategori['nama_kategori_wisata'] ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <div class="invalid-feedback">
                                            Pilih kategori wisata.
                                        </div>
                                    </div>

                                    <!-- Kabupaten -->
                                    <div class="mb-3">
                                        <label for="id_kotakabupaten" class="form-label">Kabupaten</label>
                                        <select class="form-select" id="id_kotakabupaten" name="id_kotakabupaten" required>
                                            <option value="" disabled>Pilih kabupaten</option>
                                            <?php foreach ($kotakabupaten as $kabupaten) : ?>
                                                <option value="<?= $kabupaten['id_kotakabupaten'] ?>" <?= $kabupaten['id_kotakabupaten'] == $wisata['id_kotakabupaten'] ? 'selected' : '' ?>>
                                                    <?= $kabupaten['nama_kotakabupaten'] ?>
                                                </option>
                                            <?php endforeach; ?>
                                        </select>
                                        <div class="invalid-feedback">
                                            Pilih kabupaten.
                                        </div>
                                    </div>

                                    <!-- Foto Wisata -->
                                    <div class="mb-3">
                                        <label for="foto_wisata" class="form-label">Foto Wisata (URL)</label>
                                        <input type="text" class="form-control" id="foto_wisata" name="foto_wisata" value="<?= $wisata['foto_wisata'] ?>" required>
                                        <div class="invalid-feedback">
                                            URL foto wisata wajib diisi.
                                        </div>
                                    </div>

                                    <!-- Deskripsi Wisata -->
                                    <div class="mb-3">
                                        <label for="deskripsi_wisata" class="form-label">Deskripsi Wisata</label>
                                        <textarea class="form-control" id="deskripsi_wisata" name="deskripsi_wisata" rows="3" required><?= $wisata['deskripsi_wisata'] ?></textarea>
                                        <div class="invalid-feedback">
                                            Deskripsi wisata wajib diisi.
                                        </div>
                                    </div>

                                    <!-- Nama Penulis -->
                                    <div class="mb-3">
                                        <label for="nama_penulis" class="form-label">Nama Penulis</label>
                                        <input type="text" class="form-control" id="nama_penulis" name="nama_penulis" value="<?= $wisata['nama_penulis'] ?>" required>
                                        <div class="invalid-feedback">
                                            Nama penulis wajib diisi.
                                        </div>
                                    </div>

                                    <!-- Sumber Foto -->
                                    <div class="mb-3">
                                        <label for="sumber_foto" class="form-label">Sumber Foto</label>
                                        <input type="text" class="form-control" id="sumber_foto" name="sumber_foto" value="<?= $wisata['sumber_foto'] ?>" required>
                                        <div class="invalid-feedback">
                                            Sumber foto wajib diisi.
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="row">
                                <div class="col">
                                    <button type="submit" class="btn btn-primary">Update</button>
                                </div>
                                <div class="col">
                                    <?php if (!empty(session()->getFlashdata('success'))) : ?>
                                        <div class="alert alert-success" role="alert">
                                            <?php echo session()->getFlashdata('success') ?>
                                        </div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </form>
                    </div>
                </div><!--//app-card-->
            </div>
        </div><!--//row-->
        <hr class="my-4">
    </div><!--//container-xl-->
</div><!--//app-content-->

<?= $this->endSection('content') ?>
