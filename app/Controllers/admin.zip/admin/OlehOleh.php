<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\OlehOlehModel;
use App\Models\KategoriOlehOlehModel;
use App\Models\KabupatenModel;

class OlehOleh extends BaseController
{
    protected $olehOlehModel;
    protected $kategoriOlehOlehModel;
    protected $kabupatenModel;

    public function __construct()
    {
        $this->olehOlehModel = new OlehOlehModel();
        $this->kategoriOlehOlehModel = new KategoriOlehOlehModel();
        $this->kabupatenModel = new KabupatenModel();
    }

    public function index()
    {
        $data['oleh_oleh'] = $this->olehOlehModel->getAllOlehOleh();
        return view('admin/oleh_oleh/index', $data);
    }

    public function tambah()
    {
        $data['kategori_oleh_oleh'] = $this->kategoriOlehOlehModel->findAll();
        $data['kotakabupaten'] = $this->kabupatenModel->findAll();
        return view('admin/oleh_oleh/tambah', $data);
    }

    public function proses_tambah()
    {
        $this->olehOlehModel->save([
            'id_kategori_oleholeh' => $this->request->getPost('id_kategori_oleholeh'),
            'nama_oleholeh' => $this->request->getPost('nama_oleholeh'),
            'foto_oleholeh' => $this->request->getPost('foto_oleholeh'),
            'deskripsi_oleholeh' => $this->request->getPost('deskripsi_oleholeh'),
            'id_kotakabupaten' => $this->request->getPost('id_kotakabupaten'),
            'views' => 0,
            'slug_oleholeh' => url_title($this->request->getPost('nama_oleholeh')),
            'nomor_tlp' => $this->request->getPost('nomor_tlp'),
            'link_website' => $this->request->getPost('link_website'),
        ]);

        return redirect()->to('admin/oleh_oleh/index');
    }

    public function edit($id_oleholeh)
    {
        $data['oleh_oleh'] = $this->olehOlehModel->find($id_oleholeh);
        $data['kategori_oleh_oleh'] = $this->kategoriOlehOlehModel->findAll();
        $data['kotakabupaten'] = $this->kabupatenModel->findAll();
        return view('admin/oleh_oleh/edit', $data);
    }

    public function proses_edit($id_oleholeh)
    {
        $this->olehOlehModel->update($id_oleholeh, [
            'id_kategori_oleholeh' => $this->request->getPost('id_kategori_oleholeh'),
            'nama_oleholeh' => $this->request->getPost('nama_oleholeh'),
            'foto_oleholeh' => $this->request->getPost('foto_oleholeh'),
            'deskripsi_oleholeh' => $this->request->getPost('deskripsi_oleholeh'),
            'id_kotakabupaten' => $this->request->getPost('id_kotakabupaten'),
            'nomor_tlp' => $this->request->getPost('nomor_tlp'),
            'link_website' => $this->request->getPost('link_website'),
        ]);

        return redirect()->to('admin/oleh_oleh/index');
    }

    public function delete($id_oleholeh)
    {
        $this->olehOlehModel->delete($id_oleholeh);
        return redirect()->to('admin/oleh_oleh/index');
    }
}
