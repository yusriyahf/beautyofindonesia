<?php

namespace App\Controllers\Admin;

use App\Controllers\BaseController;
use App\Models\TempatWisataModel;
use App\Models\KategoriWisataModel;
use App\Models\KabupatenModel;  // Corrected Model

class TempatWisata extends BaseController
{
    protected $tempatWisataModel;
    protected $kategoriWisataModel;
    protected $kabupatenModel;  // Corrected property

    public function __construct()
    {
        $this->tempatWisataModel = new TempatWisataModel();
        $this->kategoriWisataModel = new KategoriWisataModel();
        $this->kabupatenModel = new KabupatenModel();  // Corrected initialization
    }

    // Display list of wisata
    public function index()
    {
        $data['wisata'] = $this->tempatWisataModel->getAllWisataAdmin();
        return view('admin/wisata/index', $data);
    }

    // Show the form to add new wisata
    public function tambah()
    {
        $data['kategori_wisata'] = $this->kategoriWisataModel->findAll();
        $data['kotakabupaten'] = $this->kabupatenModel->findAll();  // Corrected reference
        return view('admin/wisata/tambah', $data);
    }

    // Process the form submission for adding new wisata
    public function proses_tambah()
    {
        $this->tempatWisataModel->save([
            'id_kategori_wisata' => $this->request->getPost('id_kategori_wisata'),
            'nama_wisata_ind' => $this->request->getPost('nama_wisata_ind'),

        ]);

        return redirect()->to('admin/tempat_wisata/index');
    }

    // Show the form to edit existing wisata
    public function edit($id_wisata)
    {
        $data['wisata'] = $this->tempatWisataModel->find($id_wisata);
        $data['kategori_wisata'] = $this->kategoriWisataModel->findAll();
        $data['kotakabupaten'] = $this->kabupatenModel->findAll();  // Corrected reference
        return view('admin/wisata/edit', $data);
    }

    // Process the form submission for editing existing wisata
    public function proses_edit($id_wisata)
    {
        $this->tempatWisataModel->update($id_wisata, [
            'id_kategori_wisata' => $this->request->getPost('id_kategori_wisata'),
            'nama_wisata' => $this->request->getPost('nama_wisata'),
            'foto_wisata' => $this->request->getPost('foto_wisata'),
            'deskripsi_wisata' => $this->request->getPost('deskripsi_wisata'),
            'id_kotakabupaten' => $this->request->getPost('id_kotakabupaten'),
            'nama_penulis' => $this->request->getPost('nama_penulis'),
            'sumber_foto' => $this->request->getPost('sumber_foto'),
        ]);

        return redirect()->to('admin/tempat_wisata/index');
    }

    // Delete wisata
    public function delete($id_wisata)
    {
        $this->tempatWisataModel->delete($id_wisata);
        return redirect()->to('admin/tempat_wisata/index');
    }
}
